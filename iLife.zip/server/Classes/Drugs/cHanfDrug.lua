--
-- Created by IntelliJ IDEA.
-- User: Noneatme
-- Date: 01.02.2015
-- Time: 01:29
-- To change this template use File | Settings | File Templates.
--

cHanfDrug = inherit(cDrug)

--[[

]]


-- ///////////////////////////////
-- ///// Constructor 		//////
-- ///// Returns: void		//////
-- ///////////////////////////////

function cHanfDrug:constructor(...)
    -- Klassenvariablen --

    -- Funktionen --


    -- Events --
end

-- EVENT HANDLER --

