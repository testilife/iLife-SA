cVendorPed = {}

function cVendorPed:constructor()
	self.Skin = iSkin
	
	self.Data = tData
end

function cVendorPed:destructor()

end

function cVendorPed:insertItem(theItem, count, price)

end

function cVendorPed:insertVehicle()

end

function cVendorPed:playerInsertItem()

end

function cVendorPed:playerInsertVehicle()

end

function cVendorPed:playerRemoveItem()

end

function cVendorPed:playerRemoveVehicle()

end

function cVendorPed:playerRemoveItem()

end

function cVendorPed:playerRemoveVehicle()

end