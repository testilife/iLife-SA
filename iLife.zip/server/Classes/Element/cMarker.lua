CMarker = inherit(CElement)

function CMarker:constructor()
end

function CMarker:destructor()
end