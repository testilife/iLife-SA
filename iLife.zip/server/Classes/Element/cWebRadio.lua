cWebRadio = {}

function cWebRadio:constructor(iID, strName, strURL)
	self.iID = iID
	self.strName = strName
	self.strURL = strURL
end

function cWebRadio:destructor()

end
--[[
function cWebRadio:play()

end

function cWebRadio:play3D()

end

function cWebRadio:stop()

end

function cWebRadio:setPaused()

end]]