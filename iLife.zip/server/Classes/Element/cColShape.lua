--
-- Created by IntelliJ IDEA.
-- User: Noneatme
-- Date: 23.12.2014
-- Time: 13:36
-- Project: MTA iLife
--

CColShape = inherit(CElement)

registerElementClass("colshape", CColShape)

function CColShape:constructor()

end

function CColShape:destructor()

end

