function string:tonumber()
    return tonumber(self)
end
