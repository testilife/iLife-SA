CVehicle = inherit(CElement)
registerElementClass("vehicle", CVehicle)

function CVehicle:constructor()

end

function CVehicle:destructor()

end