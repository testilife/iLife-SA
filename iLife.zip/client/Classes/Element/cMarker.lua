--
-- Created by IntelliJ IDEA.
-- User: Noneatme
-- Date: 23.12.2014
-- Time: 13:36
-- Project: MTA iLife
--

CMarker = inherit(CElement)

registerElementClass("marker", CMarker)

function CMarker:constructor()

end

function CMarker:destructor()

end

