--
-- Created by IntelliJ IDEA.
-- User: Noneatme
-- Date: 23.12.2014
-- Time: 13:36
-- Project: MTA iLife
--

CEffect = inherit(CElement)

registerElementClass("effect", CEffect)

function CEffect:constructor()

end

function CEffect:destructor()

end

